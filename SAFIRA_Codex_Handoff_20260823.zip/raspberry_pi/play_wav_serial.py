import argparse
import math
import struct
import time
import wave


SPK_MAGIC = b"SPK0"
SAMPLE_RATE = 16000
FRAME_SAMPLES = 320
HEADER = struct.Struct("<4sHH")


class LowPassFilter:
    def __init__(self, cutoff_hz):
        self.prev = 0.0
        self.enabled = cutoff_hz > 0
        if self.enabled:
            rc = 1.0 / (2.0 * math.pi * cutoff_hz)
            dt = 1.0 / SAMPLE_RATE
            self.alpha = dt / (rc + dt)
        else:
            self.alpha = 1.0

    def apply(self, payload):
        if not self.enabled:
            return payload
        sample_count = len(payload) // 2
        samples = struct.unpack("<" + ("h" * sample_count), payload)
        filtered = []
        y = self.prev
        for sample in samples:
            y += self.alpha * (sample - y)
            filtered.append(max(-32768, min(32767, int(y))))
        self.prev = y
        return struct.pack("<" + ("h" * sample_count), *filtered)


def start_bridge(port):
    deadline = time.time() + 8
    last_start = 0
    while time.time() < deadline:
        if time.time() - last_start >= 1:
            port.write(b"START\n")
            last_start = time.time()
        line = port.readline().decode("ascii", errors="ignore").strip()
        if line:
            print(line)
        if line == "STARTED":
            return
    raise TimeoutError("ESP32 STARTED message not received")


def read_wav_mono_16(path):
    with wave.open(path, "rb") as wav:
        if wav.getsampwidth() != 2:
            raise ValueError("expected 16-bit PCM WAV")
        if wav.getframerate() != SAMPLE_RATE:
            raise ValueError(f"expected {SAMPLE_RATE} Hz WAV")
        channels = wav.getnchannels()
        raw = wav.readframes(wav.getnframes())

    if channels == 1:
        return raw
    if channels != 2:
        raise ValueError("expected mono or stereo WAV")

    samples = struct.unpack("<" + ("h" * (len(raw) // 2)), raw)
    mono = []
    for i in range(0, len(samples), 2):
        mono.append((samples[i] + samples[i + 1]) // 2)
    return struct.pack("<" + ("h" * len(mono)), *mono)


def scale_pcm16(payload, volume):
    volume = max(0.0, min(1.0, volume))
    sample_count = len(payload) // 2
    samples = struct.unpack("<" + ("h" * sample_count), payload)
    scaled = [max(-32768, min(32767, int(sample * volume))) for sample in samples]
    return struct.pack("<" + ("h" * sample_count), *scaled)


def main():
    import serial

    parser = argparse.ArgumentParser(description="Play a 16 kHz 16-bit WAV through ESP32 -> PCM5102A -> PAM8403.")
    parser.add_argument("wav")
    parser.add_argument("--port", default="COM3")
    parser.add_argument("--volume", type=float, default=0.01)
    parser.add_argument("--lowpass", type=float, default=2400.0)
    args = parser.parse_args()

    lowpass = LowPassFilter(args.lowpass)
    audio = lowpass.apply(scale_pcm16(read_wav_mono_16(args.wav), args.volume))
    frame_bytes = FRAME_SAMPLES * 2
    sequence = 0

    with serial.Serial(args.port, 2000000, timeout=1, write_timeout=1) as port:
        port.reset_input_buffer()
        port.reset_output_buffer()
        start_bridge(port)
        port.timeout = 0

        start = time.perf_counter()
        for offset in range(0, len(audio), frame_bytes):
            payload = audio[offset:offset + frame_bytes]
            if len(payload) < frame_bytes:
                payload += b"\x00" * (frame_bytes - len(payload))

            port.write(HEADER.pack(SPK_MAGIC, sequence & 0xFFFF, FRAME_SAMPLES))
            port.write(payload)
            sequence += 1

            if port.in_waiting:
                port.read(port.in_waiting)

            next_time = start + (sequence * FRAME_SAMPLES / SAMPLE_RATE)
            sleep_for = next_time - time.perf_counter()
            if sleep_for > 0:
                time.sleep(sleep_for)

    print("DONE")


if __name__ == "__main__":
    main()
