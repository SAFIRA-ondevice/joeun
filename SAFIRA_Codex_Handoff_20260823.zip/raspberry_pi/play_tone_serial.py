import argparse
import math
import struct
import time


SPK_MAGIC = b"SPK0"
SAMPLE_RATE = 16000
FRAME_SAMPLES = 320
HEADER = struct.Struct("<4sHH")


def start_bridge(port):
    deadline = time.time() + 8
    last_start = 0
    while time.time() < deadline:
        if time.time() - last_start >= 1:
            port.write(b"START\n")
            last_start = time.time()
        line = port.readline().decode("ascii", errors="ignore").strip()
        if line:
            print(line)
        if line == "STARTED":
            return
    raise TimeoutError("ESP32 STARTED message not received")


def make_frame(sequence, frequency_hz, amplitude):
    samples = []
    base = sequence * FRAME_SAMPLES
    for i in range(FRAME_SAMPLES):
        t = (base + i) / SAMPLE_RATE
        samples.append(int(amplitude * math.sin(2.0 * math.pi * frequency_hz * t)))
    return struct.pack("<" + ("h" * FRAME_SAMPLES), *samples)


def main():
    import serial

    parser = argparse.ArgumentParser(description="Play a sine test tone through ESP32 -> PCM5102A -> PAM8403.")
    parser.add_argument("--port", default="COM3")
    parser.add_argument("--seconds", type=float, default=5.0)
    parser.add_argument("--freq", type=float, default=440.0)
    parser.add_argument("--volume", type=float, default=0.25)
    args = parser.parse_args()

    amplitude = max(0, min(32767, int(32767 * args.volume)))
    total_frames = int(args.seconds * SAMPLE_RATE / FRAME_SAMPLES)

    with serial.Serial(args.port, 2000000, timeout=1, write_timeout=1) as port:
        port.reset_input_buffer()
        port.reset_output_buffer()
        start_bridge(port)
        port.timeout = 0

        start = time.perf_counter()
        for sequence in range(total_frames):
            payload = make_frame(sequence, args.freq, amplitude)
            port.write(HEADER.pack(SPK_MAGIC, sequence & 0xFFFF, FRAME_SAMPLES))
            port.write(payload)

            if port.in_waiting:
                port.read(port.in_waiting)

            next_time = start + ((sequence + 1) * FRAME_SAMPLES / SAMPLE_RATE)
            sleep_for = next_time - time.perf_counter()
            if sleep_for > 0:
                time.sleep(sleep_for)

    print("DONE")


if __name__ == "__main__":
    main()
