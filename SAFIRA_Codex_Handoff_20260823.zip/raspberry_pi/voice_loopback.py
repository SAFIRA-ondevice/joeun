import argparse
import math
import struct
import time
import wave


MIC_MAGIC = b"M3C0"
SPK_MAGIC = b"SPK0"
DBG_MAGIC = b"DBG0"
SAMPLE_RATE = 16000
FRAME_SAMPLES = 320
INPUT_CHANNELS = 3
HEADER = struct.Struct("<4sHH")
DBG_PAYLOAD = struct.Struct("<IIIIII")
MIC_PACKET_BYTES = HEADER.size + (FRAME_SAMPLES * INPUT_CHANNELS * 2)


class LowPassFilter:
    def __init__(self, cutoff_hz):
        self.prev = 0.0
        self.enabled = cutoff_hz > 0
        if self.enabled:
            rc = 1.0 / (2.0 * math.pi * cutoff_hz)
            dt = 1.0 / SAMPLE_RATE
            self.alpha = dt / (rc + dt)
        else:
            self.alpha = 1.0

    def apply(self, payload):
        if not self.enabled:
            return payload
        samples = struct.unpack("<" + ("h" * FRAME_SAMPLES), payload)
        filtered = []
        y = self.prev
        for sample in samples:
            y += self.alpha * (sample - y)
            filtered.append(max(-32768, min(32767, int(y))))
        self.prev = y
        return struct.pack("<" + ("h" * FRAME_SAMPLES), *filtered)


def start_bridge(port, command):
    start_line = (command + "\n").encode("ascii")
    deadline = time.time() + 8
    last_start = 0
    line_buffer = bytearray()
    packet_probe = bytearray()
    while time.time() < deadline:
        if time.time() - last_start >= 1:
            port.write(start_line)
            last_start = time.time()

        chunk = port.read(max(1, getattr(port, "in_waiting", 0) or 1))
        if not chunk:
            continue

        packet_probe.extend(chunk)
        if MIC_MAGIC in packet_probe or DBG_MAGIC in packet_probe:
            print("ESP32 is already streaming binary audio; continuing.")
            return
        keep = max(len(MIC_MAGIC), len(DBG_MAGIC)) - 1
        if len(packet_probe) > keep:
            del packet_probe[:-keep]

        for value in chunk:
            if value in (10, 13):
                line = line_buffer.decode("ascii", errors="ignore").strip()
                line_buffer.clear()
                if line:
                    print(line)
                if line == "STARTED":
                    return
            elif 32 <= value <= 126:
                line_buffer.append(value)
            else:
                line_buffer.clear()
    raise TimeoutError("ESP32 STARTED message not received")


class MicPacketReader:
    def __init__(self):
        self.buffer = bytearray()
        self.bad_headers = 0
        self.resync_bytes = 0
        self.debug_packets = 0
        self.last_debug = None

    def _pop_packet(self):
        while True:
            mic_at = self.buffer.find(MIC_MAGIC)
            dbg_at = self.buffer.find(DBG_MAGIC)
            candidates = [(idx, magic) for idx, magic in ((mic_at, MIC_MAGIC), (dbg_at, DBG_MAGIC)) if idx >= 0]
            magic_at, magic = min(candidates, default=(-1, b""), key=lambda item: item[0])
            if magic_at < 0:
                keep = max(len(MIC_MAGIC), len(DBG_MAGIC)) - 1
                if len(self.buffer) > keep:
                    self.resync_bytes += len(self.buffer) - keep
                    del self.buffer[:-keep]
                return None

            if magic_at > 0:
                self.resync_bytes += magic_at
                del self.buffer[:magic_at]

            if len(self.buffer) < HEADER.size:
                return None

            _, sequence, samples = HEADER.unpack(bytes(self.buffer[:HEADER.size]))
            if magic == DBG_MAGIC:
                if samples != DBG_PAYLOAD.size:
                    self.bad_headers += 1
                    del self.buffer[0]
                    continue
                packet_bytes = HEADER.size + DBG_PAYLOAD.size
                if len(self.buffer) < packet_bytes:
                    return None
                values = DBG_PAYLOAD.unpack(bytes(self.buffer[HEADER.size:packet_bytes]))
                self.last_debug = {
                    "seq": sequence,
                    "uptime_ms": values[0],
                    "mic_frames": values[1],
                    "speaker_packets": values[2],
                    "speaker_frames": values[3],
                    "adc_frames": values[4],
                    "free_heap": values[5],
                }
                self.debug_packets += 1
                del self.buffer[:packet_bytes]
                continue

            if samples != FRAME_SAMPLES:
                self.bad_headers += 1
                del self.buffer[0]
                continue

            if len(self.buffer) < MIC_PACKET_BYTES:
                return None

            payload = bytes(self.buffer[HEADER.size:MIC_PACKET_BYTES])
            del self.buffer[:MIC_PACKET_BYTES]
            return sequence, payload

    def read_packet(self, port):
        while True:
            packet = self._pop_packet()
            if packet is not None:
                return packet

            chunk = port.read(max(1, port.in_waiting or 1))
            if not chunk:
                raise TimeoutError(
                    "timed out while waiting for M3C0 packet; "
                    f"pending={len(self.buffer)}B debug={self.last_debug}"
                )
            self.buffer.extend(chunk)


def write_speaker_packet(port, sequence, payload):
    port.write(HEADER.pack(SPK_MAGIC, sequence & 0xFFFF, FRAME_SAMPLES) + payload)


def scale_pcm16(payload, volume):
    volume = max(0.0, min(1.0, volume))
    samples = struct.unpack("<" + ("h" * FRAME_SAMPLES), payload)
    scaled = [max(-32768, min(32767, int(sample * volume))) for sample in samples]
    return struct.pack("<" + ("h" * FRAME_SAMPLES), *scaled)


def mix_input_channels(payload, output):
    samples = struct.unpack("<" + ("h" * FRAME_SAMPLES * INPUT_CHANNELS), payload)
    mixed = []
    for i in range(FRAME_SAMPLES):
        left = samples[(i * INPUT_CHANNELS) + 0]
        right = samples[(i * INPUT_CHANNELS) + 1]
        voice = samples[(i * INPUT_CHANNELS) + 2]
        if output == "left":
            value = left
        elif output == "right":
            value = right
        elif output == "ambient":
            value = (left + right) // 2
        elif output in ("voice", "max"):
            value = voice
        else:
            value = (left + right + voice) // 3
        mixed.append(max(-32768, min(32767, value)))
    return struct.pack("<" + ("h" * FRAME_SAMPLES), *mixed)


def split_input_channels(frames):
    channels = [[], [], []]
    for payload in frames:
        samples = struct.unpack("<" + ("h" * FRAME_SAMPLES * INPUT_CHANNELS), payload)
        for i in range(FRAME_SAMPLES):
            channels[0].append(samples[(i * INPUT_CHANNELS) + 0])
            channels[1].append(samples[(i * INPUT_CHANNELS) + 1])
            channels[2].append(samples[(i * INPUT_CHANNELS) + 2])
    return [struct.pack("<" + ("h" * len(channel)), *channel) for channel in channels]


def save_channel_wavs(path, frames):
    if not path:
        return
    names = ["ambient_left", "ambient_right", "voice"]
    base = path[:-4] if path.lower().endswith(".wav") else path
    for name, pcm in zip(names, split_input_channels(frames)):
        out_path = f"{base}_{name}.wav"
        with wave.open(out_path, "wb") as wav:
            wav.setnchannels(1)
            wav.setsampwidth(2)
            wav.setframerate(SAMPLE_RATE)
            wav.writeframes(pcm)
        print(out_path)


def format_debug(debug):
    if not debug:
        return "dbg=none"
    return (
        f"dbg=up:{debug['uptime_ms']}ms "
        f"mic:{debug['mic_frames']} spk_rx:{debug['speaker_packets']} "
        f"spk_tx:{debug['speaker_frames']} adc:{debug['adc_frames']} "
        f"heap:{debug['free_heap']}"
    )


def main():
    import serial

    parser = argparse.ArgumentParser(description="Echo ESP32 mic packets back to PCM5102A/PAM8403 speaker output.")
    parser.add_argument("--port", default="COM3")
    parser.add_argument("--seconds", type=float, default=20.0)
    parser.add_argument("--volume", type=float, default=0.01)
    parser.add_argument("--lowpass", type=float, default=2400.0)
    parser.add_argument("--output", choices=["mix", "ambient", "voice", "max", "left", "right"], default="mix")
    parser.add_argument("--no-speaker", action="store_true", help="Receive and save mic audio without sending speaker packets back.")
    parser.add_argument("--esp-mic-only", action="store_true", help="Start ESP32 without its speaker output task for isolation testing.")
    parser.add_argument("--esp-inmp-only", action="store_true", help="Start ESP32 with INMP441x3 input only; speaker output stays off.")
    parser.add_argument("--esp-inmp-speaker", action="store_true", help="Start ESP32 with INMP441x3 input and speaker output.")
    parser.add_argument("--esp-fake-only", action="store_true", help="Start ESP32 with fake silent input only; mics and speaker output stay off.")
    parser.add_argument("--save", default="")
    args = parser.parse_args()

    frames = []
    lowpass = LowPassFilter(args.lowpass)
    reader = MicPacketReader()
    with serial.Serial(args.port, 2000000, timeout=1, write_timeout=1) as port:
        port.reset_input_buffer()
        port.reset_output_buffer()
        if args.esp_fake_only:
            start_command = "START_FAKE_ONLY"
        elif args.esp_inmp_speaker:
            start_command = "START_INMP_SPEAKER"
        elif args.esp_inmp_only:
            start_command = "START_INMP_ONLY"
        elif args.esp_mic_only:
            start_command = "START_MIC_ONLY"
        else:
            start_command = "START"
        start_bridge(port, start_command)

        target_frames = max(1, round(args.seconds * SAMPLE_RATE / FRAME_SAMPLES))
        frame_count = 0
        started_at = time.time()
        last_print = time.time()
        while frame_count < target_frames:
            sequence, payload = reader.read_packet(port)
            if not args.no_speaker:
                speaker_payload = mix_input_channels(payload, args.output)
                speaker_payload = lowpass.apply(scale_pcm16(speaker_payload, args.volume))
                write_speaker_packet(port, sequence, speaker_payload)
            if args.save:
                frames.append(payload)
            frame_count += 1
            if time.time() - last_print >= 1:
                audio_seconds = frame_count * FRAME_SAMPLES / SAMPLE_RATE
                wall_seconds = time.time() - started_at
                realtime = audio_seconds / wall_seconds if wall_seconds > 0 else 0.0
                print(
                    f"looped {audio_seconds:.1f}/{args.seconds:.1f} sec audio, "
                    f"{wall_seconds:.1f} sec wall, realtime={realtime:.2f}x, "
                    f"resync={reader.bad_headers}/{reader.resync_bytes}B, "
                    f"{format_debug(reader.last_debug)}"
                )
                last_print = time.time()

        wall_seconds = time.time() - started_at
        audio_seconds = frame_count * FRAME_SAMPLES / SAMPLE_RATE
        realtime = audio_seconds / wall_seconds if wall_seconds > 0 else 0.0
        print(
            f"captured {audio_seconds:.2f} sec audio in {wall_seconds:.2f} sec wall, "
            f"realtime={realtime:.2f}x, resync={reader.bad_headers}/{reader.resync_bytes}B, "
            f"{format_debug(reader.last_debug)}"
        )

    save_channel_wavs(args.save, frames)


if __name__ == "__main__":
    main()
