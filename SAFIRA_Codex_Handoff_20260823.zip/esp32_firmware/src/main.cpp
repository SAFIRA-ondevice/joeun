#include <Arduino.h>
#include <driver/i2s.h>
#include <esp_log.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/task.h>
#include <string.h>

#ifndef I2S_COMM_FORMAT_STAND_I2S
#define I2S_COMM_FORMAT_STAND_I2S I2S_COMM_FORMAT_I2S
#endif

static constexpr uint32_t SERIAL_BAUD = 2000000;
static constexpr int SAMPLE_RATE_HZ = 16000;
static constexpr size_t FRAME_SAMPLES = 320;
static constexpr size_t INPUT_CHANNELS = 3;

static constexpr i2s_port_t I2S_AMB_PORT = I2S_NUM_0;
static constexpr int PIN_AMB_BCLK = 26;
static constexpr int PIN_AMB_WS = 25;
static constexpr int PIN_AMB_DIN = 34;

static constexpr i2s_port_t I2S_AUD_PORT = I2S_NUM_1;
static constexpr int PIN_AUD_BCLK = 27;
static constexpr int PIN_AUD_WS = 14;
static constexpr int PIN_VOICE_DIN = 35;
static constexpr int PIN_DAC_DOUT = 22;

static constexpr uint8_t MIC_MAGIC[4] = {'M', '3', 'C', '0'};
static constexpr uint8_t SPK_MAGIC[4] = {'S', 'P', 'K', '0'};
static constexpr uint8_t DBG_MAGIC[4] = {'D', 'B', 'G', '0'};
static constexpr size_t PACKET_HEADER_BYTES = 8;
static constexpr size_t MIC_PACKET_PAYLOAD_BYTES = FRAME_SAMPLES * INPUT_CHANNELS * sizeof(int16_t);
static constexpr size_t SPK_PACKET_PAYLOAD_BYTES = FRAME_SAMPLES * sizeof(int16_t);
static constexpr size_t SPK_PACKET_BYTES = PACKET_HEADER_BYTES + SPK_PACKET_PAYLOAD_BYTES;
static constexpr size_t DBG_PACKET_PAYLOAD_BYTES = 6 * sizeof(uint32_t);
static constexpr size_t SPEAKER_FRAME_BUFFER_COUNT = 6;

struct SpeakerFrame {
  int16_t pcm[FRAME_SAMPLES];
};

enum class InputMode {
  Full,
  Fake,
};

static int32_t ambRaw[FRAME_SAMPLES * 2];
static int32_t voiceRaw[FRAME_SAMPLES * 2];
static int32_t stereoOut32[FRAME_SAMPLES * 2];
static int16_t mic3Pcm[FRAME_SAMPLES * INPUT_CHANNELS];
static int16_t silencePcm[FRAME_SAMPLES] = {};
static uint8_t rxPacket[SPK_PACKET_BYTES];
static size_t rxLen = 0;
static uint16_t txSequence = 0;
static uint16_t debugSequence = 0;
static bool bridgeStarted = false;
static bool bridgeTasksStarted = false;
static InputMode inputMode = InputMode::Full;
static volatile uint32_t micFramesSent = 0;
static volatile uint32_t speakerPacketsReceived = 0;
static volatile uint32_t speakerFramesWritten = 0;
static volatile uint32_t voiceFramesRead = 0;
static QueueHandle_t speakerFrameQueue = nullptr;

static int16_t clamp16(int32_t value) {
  if (value > 32767) {
    return 32767;
  }
  if (value < -32768) {
    return -32768;
  }
  return static_cast<int16_t>(value);
}

static int16_t scaleI2sMicSample(int32_t raw) {
  return clamp16(raw >> 14);
}

static void failFast(const char *label, esp_err_t err) {
  if (err == ESP_OK) {
    return;
  }
  Serial.print(label);
  Serial.print(" failed: ");
  Serial.println(esp_err_to_name(err));
  while (true) {
    delay(1000);
  }
}

static void writeLe16(uint8_t *dst, uint16_t value) {
  dst[0] = static_cast<uint8_t>(value & 0xff);
  dst[1] = static_cast<uint8_t>((value >> 8) & 0xff);
}

static void writeLe32(uint8_t *dst, uint32_t value) {
  dst[0] = static_cast<uint8_t>(value & 0xff);
  dst[1] = static_cast<uint8_t>((value >> 8) & 0xff);
  dst[2] = static_cast<uint8_t>((value >> 16) & 0xff);
  dst[3] = static_cast<uint8_t>((value >> 24) & 0xff);
}

static uint16_t readLe16(const uint8_t *src) {
  return static_cast<uint16_t>(src[0]) | (static_cast<uint16_t>(src[1]) << 8);
}

static i2s_config_t baseI2sConfig(i2s_mode_t mode) {
  i2s_config_t config = {};
  config.mode = mode;
  config.sample_rate = SAMPLE_RATE_HZ;
  config.bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT;
  config.channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT;
  config.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  config.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  config.dma_buf_count = 4;
  config.dma_buf_len = FRAME_SAMPLES;
  config.use_apll = false;
  config.tx_desc_auto_clear = true;
  config.fixed_mclk = 0;
  return config;
}

static void configureAmbientI2s() {
  i2s_config_t config = baseI2sConfig(static_cast<i2s_mode_t>(I2S_MODE_MASTER | I2S_MODE_RX));

  i2s_pin_config_t pins = {};
  pins.bck_io_num = PIN_AMB_BCLK;
  pins.ws_io_num = PIN_AMB_WS;
  pins.data_out_num = I2S_PIN_NO_CHANGE;
  pins.data_in_num = PIN_AMB_DIN;

  failFast("i2s_driver_install ambient", i2s_driver_install(I2S_AMB_PORT, &config, 0, nullptr));
  failFast("i2s_set_pin ambient", i2s_set_pin(I2S_AMB_PORT, &pins));
  failFast("i2s_zero_dma_buffer ambient", i2s_zero_dma_buffer(I2S_AMB_PORT));
}

static void configureAudioI2s() {
  i2s_config_t config = baseI2sConfig(static_cast<i2s_mode_t>(I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_RX));

  i2s_pin_config_t pins = {};
  pins.bck_io_num = PIN_AUD_BCLK;
  pins.ws_io_num = PIN_AUD_WS;
  pins.data_out_num = PIN_DAC_DOUT;
  pins.data_in_num = PIN_VOICE_DIN;

  failFast("i2s_driver_install audio", i2s_driver_install(I2S_AUD_PORT, &config, 0, nullptr));
  failFast("i2s_set_pin audio", i2s_set_pin(I2S_AUD_PORT, &pins));
  failFast("i2s_zero_dma_buffer audio", i2s_zero_dma_buffer(I2S_AUD_PORT));
}

static size_t readI2sFrame(i2s_port_t port, int32_t *buffer) {
  size_t bytesRead = 0;
  const esp_err_t err = i2s_read(
      port,
      buffer,
      FRAME_SAMPLES * 2 * sizeof(int32_t),
      &bytesRead,
      pdMS_TO_TICKS(100));
  if (err != ESP_OK || bytesRead == 0) {
    return 0;
  }
  return bytesRead / (sizeof(int32_t) * 2);
}

static void readInputFrame() {
  if (inputMode == InputMode::Fake) {
    static TickType_t lastWake = xTaskGetTickCount();
    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(20));
    memset(mic3Pcm, 0, sizeof(mic3Pcm));
    return;
  }

  const size_t ambFrames = readI2sFrame(I2S_AMB_PORT, ambRaw);
  const size_t voiceFrames = readI2sFrame(I2S_AUD_PORT, voiceRaw);
  if (voiceFrames > 0) {
    ++voiceFramesRead;
  }

  for (size_t i = 0; i < FRAME_SAMPLES; ++i) {
    const bool hasAmb = i < ambFrames;
    const bool hasVoice = i < voiceFrames;
    mic3Pcm[(i * INPUT_CHANNELS) + 0] = hasAmb ? scaleI2sMicSample(ambRaw[(i * 2) + 0]) : 0;
    mic3Pcm[(i * INPUT_CHANNELS) + 1] = hasAmb ? scaleI2sMicSample(ambRaw[(i * 2) + 1]) : 0;
    mic3Pcm[(i * INPUT_CHANNELS) + 2] = hasVoice ? scaleI2sMicSample(voiceRaw[(i * 2) + 0]) : 0;
  }
}

static void sendInputPacket() {
  uint8_t header[PACKET_HEADER_BYTES] = {};
  memcpy(header, MIC_MAGIC, sizeof(MIC_MAGIC));
  writeLe16(header + 4, txSequence++);
  writeLe16(header + 6, FRAME_SAMPLES);
  Serial.write(header, sizeof(header));
  Serial.write(reinterpret_cast<const uint8_t *>(mic3Pcm), MIC_PACKET_PAYLOAD_BYTES);
  ++micFramesSent;
}

static void sendDebugPacket() {
  uint8_t header[PACKET_HEADER_BYTES] = {};
  uint8_t payload[DBG_PACKET_PAYLOAD_BYTES] = {};
  memcpy(header, DBG_MAGIC, sizeof(DBG_MAGIC));
  writeLe16(header + 4, debugSequence++);
  writeLe16(header + 6, DBG_PACKET_PAYLOAD_BYTES);
  writeLe32(payload + 0, millis());
  writeLe32(payload + 4, micFramesSent);
  writeLe32(payload + 8, speakerPacketsReceived);
  writeLe32(payload + 12, speakerFramesWritten);
  writeLe32(payload + 16, voiceFramesRead);
  writeLe32(payload + 20, ESP.getFreeHeap());
  Serial.write(header, sizeof(header));
  Serial.write(payload, sizeof(payload));
}

static void resetRxSync() {
  rxLen = 0;
}

static bool pushRxByte(uint8_t value) {
  if (rxLen < 4) {
    if (value == SPK_MAGIC[rxLen]) {
      rxPacket[rxLen++] = value;
    } else {
      rxLen = (value == SPK_MAGIC[0]) ? 1 : 0;
      if (rxLen == 1) {
        rxPacket[0] = value;
      }
    }
    return false;
  }

  rxPacket[rxLen++] = value;
  if (rxLen < SPK_PACKET_BYTES) {
    return false;
  }

  const uint16_t sampleCount = readLe16(rxPacket + 6);
  if (sampleCount != FRAME_SAMPLES) {
    resetRxSync();
    return false;
  }

  SpeakerFrame frame = {};
  memcpy(frame.pcm, rxPacket + PACKET_HEADER_BYTES, SPK_PACKET_PAYLOAD_BYTES);
  if (xQueueSend(speakerFrameQueue, &frame, 0) != pdTRUE) {
    SpeakerFrame oldFrame = {};
    xQueueReceive(speakerFrameQueue, &oldFrame, 0);
    xQueueSend(speakerFrameQueue, &frame, 0);
  }
  ++speakerPacketsReceived;
  resetRxSync();
  return true;
}

static void readAvailableSpeakerBytes() {
  while (Serial.available() > 0) {
    const int value = Serial.read();
    if (value < 0) {
      break;
    }
    pushRxByte(static_cast<uint8_t>(value));
  }
}

static void writeSpeakerFrame(const int16_t *mono) {
  for (size_t i = 0; i < FRAME_SAMPLES; ++i) {
    const int32_t sample32 = static_cast<int32_t>(mono[i]) << 16;
    stereoOut32[(i * 2) + 0] = sample32;
    stereoOut32[(i * 2) + 1] = sample32;
  }

  size_t bytesWritten = 0;
  i2s_write(
      I2S_AUD_PORT,
      stereoOut32,
      sizeof(stereoOut32),
      &bytesWritten,
      pdMS_TO_TICKS(25));
}

static void bridgeIoTask(void *) {
  uint32_t lastDebugAt = 0;
  while (true) {
    readAvailableSpeakerBytes();
    readInputFrame();
    sendInputPacket();
    readAvailableSpeakerBytes();
    const uint32_t now = millis();
    if (now - lastDebugAt >= 1000) {
      sendDebugPacket();
      lastDebugAt = now;
    }
  }
}

static void speakerTxTask(void *) {
  SpeakerFrame frame = {};
  while (true) {
    if (xQueueReceive(speakerFrameQueue, &frame, pdMS_TO_TICKS(20)) == pdTRUE) {
      writeSpeakerFrame(frame.pcm);
    } else {
      writeSpeakerFrame(silencePcm);
    }
    ++speakerFramesWritten;
  }
}

static void startBridgeTasks(bool startSpeakerTask, InputMode mode) {
  if (bridgeTasksStarted) {
    return;
  }
  bridgeTasksStarted = true;
  inputMode = mode;
  if (startSpeakerTask) {
    xTaskCreatePinnedToCore(speakerTxTask, "speakerTx", 4096, nullptr, 4, nullptr, 0);
  }
  xTaskCreatePinnedToCore(bridgeIoTask, "bridgeIo", 4096, nullptr, 4, nullptr, 1);
}

void setup() {
  esp_log_level_set("*", ESP_LOG_NONE);
  Serial.setRxBufferSize(4096);
  Serial.begin(SERIAL_BAUD);
  delay(700);

  configureAmbientI2s();
  configureAudioI2s();
  speakerFrameQueue = xQueueCreate(SPEAKER_FRAME_BUFFER_COUNT, sizeof(SpeakerFrame));
  if (speakerFrameQueue == nullptr) {
    Serial.println("speaker queue allocation failed");
    while (true) {
      delay(1000);
    }
  }

  Serial.println("SAFIRA WROOM-32D carrier INMP441x3 USB speaker bridge");
  Serial.println("M3C0 packets: ESP32 -> PC, channels=ambient_left,ambient_right,voice");
  Serial.println("SPK0 packets: PC -> ESP32 -> PCM5102A/PAM8403");
  Serial.print("ambient I2S0 pins: BCLK=");
  Serial.print(PIN_AMB_BCLK);
  Serial.print(" WS=");
  Serial.print(PIN_AMB_WS);
  Serial.print(" DIN=");
  Serial.println(PIN_AMB_DIN);
  Serial.print("audio I2S1 full-duplex pins: BCLK=");
  Serial.print(PIN_AUD_BCLK);
  Serial.print(" WS=");
  Serial.print(PIN_AUD_WS);
  Serial.print(" DIN=");
  Serial.print(PIN_VOICE_DIN);
  Serial.print(" DOUT=");
  Serial.println(PIN_DAC_DOUT);
  Serial.println("Send START to begin binary audio.");
  Serial.println("READY");
}

void loop() {
  if (!bridgeStarted) {
    if (Serial.available() > 0) {
      String command = Serial.readStringUntil('\n');
      command.trim();
      if (command == "START" || command == "START_MIC_ONLY" || command == "START_INMP_ONLY" || command == "START_INMP_SPEAKER" || command == "START_FAKE_ONLY") {
        bridgeStarted = true;
        Serial.println("STARTED");
        if (command == "START_FAKE_ONLY") {
          startBridgeTasks(false, InputMode::Fake);
        } else if (command == "START_MIC_ONLY" || command == "START_INMP_ONLY") {
          startBridgeTasks(false, InputMode::Full);
        } else {
          startBridgeTasks(true, InputMode::Full);
        }
      }
    }
    delay(10);
    return;
  }

  delay(1000);
}
