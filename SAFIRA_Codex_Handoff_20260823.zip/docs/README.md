# ESP32 INMP441x3 Raspberry Pi PCM16 Speaker Bridge

ESP32-WROOM-32D의 INMP441 마이크 3채널을 SAFIRA PCM16 규격으로 Raspberry Pi에
보내고, Raspberry Pi의 ALSA 스피커로 실시간 재생하는 PlatformIO 프로젝트다.

```text
INMP441 ambient L/R + INMP441 voice
  -> ESP32-WROOM-32D
  -> Micro USB serial (M3C0 PCM16)
  -> Raspberry Pi
  -> ALSA aplay
  -> speaker
```

## 핀맵

| 기능 | ESP32 GPIO | net | 연결 |
|---|---:|---|---|
| 주변음 BCLK | GPIO26 | `MIC_BCLK` | ambient L/R INMP441 BCLK |
| 주변음 WS/LRCLK | GPIO25 | `MIC_WS` | ambient L/R INMP441 WS |
| 주변음 SD | GPIO34 | `AMB_SD` | ambient L/R INMP441 SD 공유 |
| 사용자/출력 BCLK | GPIO27 | `AUD_BCLK` | voice INMP441 BCLK + PCM5102A BCK |
| 사용자/출력 WS/LRCLK | GPIO14 | `AUD_WS` | voice INMP441 WS + PCM5102A LRCK |
| 사용자 SD | GPIO35 | `VOICE_SD` | voice INMP441 SD |
| DAC data out | GPIO22 | `DAC_DIN` | PCM5102A DIN |

`SPK-`는 GND가 아니다. PAM8403의 `L+/L-` 또는 `R+/R-` 한 쌍만 스피커에 연결한다.

## SAFIRA PCM16 규격

| 항목 | 값 |
|---|---:|
| USB serial baud | 2,000,000 |
| sample rate | 16,000 Hz |
| sample format | signed PCM16 little-endian |
| frame | 채널당 320 samples, 20 ms |
| 채널 수 | 3 |
| 채널 순서 | ambient_left, ambient_right, voice |
| input packet | `M3C0` + uint16 sequence + uint16 sample count + PCM16 |

ESP32는 `START_INMP_ONLY`를 받으면 M3C0 스트림을 시작한다. Raspberry Pi 수신기는
이미 송신 중인 ESP32를 발견한 경우에도 스트림 패킷을 감지해 바로 이어받는다.

## ESP32 업로드

VS Code에서 이 폴더를 열고 PlatformIO의 `Upload`를 실행한다. 기본 포트는 `COM3`이다.
시리얼 모니터 속도는 2,000,000 baud이고 펌웨어 업로드 속도는 921,600 baud를 유지한다.

## Raspberry Pi 스피커 재생

같은 Micro USB 케이블로 ESP32를 Raspberry Pi에 연결한다. 포트는 보통
`/dev/ttyUSB0` 또는 `/dev/ttyACM0`이다.

```bash
cd ~/SAFIRA/prototype/cods/esp32_inmp3_usb_speaker_bridge_platformio
python3 -m pip install pyserial
sudo apt install -y alsa-utils
ls -l /dev/ttyUSB* /dev/ttyACM* 2>/dev/null
aplay -l
python3 tools/raspi_pcm16_stream.py --port /dev/ttyUSB0 --speaker mix
```

`--speaker mix`는 ambient left, ambient right, voice를 평균내어 mono PCM16으로
재생한다. 기본값도 `mix`다. `Ctrl+C`로 종료한다.

특정 ALSA 출력 장치를 지정하거나 20초 동안 WAV 파일도 남길 때:

```bash
python3 tools/raspi_pcm16_stream.py \
  --port /dev/ttyUSB0 \
  --speaker mix \
  --speaker-device default \
  --seconds 20 \
  --save-prefix pi_mix
```

생성 파일:

```text
pi_mix_ambient_left.wav
pi_mix_ambient_right.wav
pi_mix_voice.wav
```

스피커를 사용하지 않고 수신/WAV만 확인할 때는 `--speaker none`을 사용한다.

```bash
python3 tools/raspi_pcm16_stream.py --port /dev/ttyUSB0 --speaker none --seconds 20 --save-prefix pi_capture
```

정상 동작 중에는 `missing=0`, `bad_headers=0`이 출력되는지 확인한다. `aplay`를
찾지 못한다는 오류가 나오면 `alsa-utils`가 설치됐는지 확인한다.

## PC에서 ESP32 DAC로 루프백

Raspberry Pi가 아니라 PC에서 PCM5102A 스피커로 되돌리는 기존 테스트는 새 16 kHz
규격으로 계속 사용할 수 있다. PlatformIO Monitor는 먼저 닫는다.

```powershell
"%USERPROFILE%\.platformio\penv\Scripts\python.exe" tools\voice_loopback.py --port COM3 --seconds 20 --volume 0.01 --lowpass 2400 --output voice --save voice_loopback.wav
```
